property :version, String,
          name_property: true,
          description: 'Java version to install'
