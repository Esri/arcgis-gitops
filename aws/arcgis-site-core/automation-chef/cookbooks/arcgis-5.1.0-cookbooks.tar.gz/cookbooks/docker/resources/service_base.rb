unified_mode true
use 'partial/_base'
use 'partial/_service_base'

resource_name :docker_service_base
provides :docker_service_base
provides :docker_service_manager
