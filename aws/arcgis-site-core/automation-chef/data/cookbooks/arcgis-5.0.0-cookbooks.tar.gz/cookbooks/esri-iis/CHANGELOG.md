# esri-iis CHANGELOG

This file is used to list changes made in each version of the esri-iis cookbook.

## 0.2.1

- Don't use default passwords.

## 0.2.0

- Use powershell_script resource instead of windows_feature to enable IIS features.

## 0.1.3

- Added 'install' recipe.

## 0.1.2

- Updated and locked versions of dependent cookbooks.

## 0.1.1

- Add ec2 test kitchen

## 0.1.0

- Initial release of esri-iis
