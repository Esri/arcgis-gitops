#
# Cookbook Name:: arcgis-enterprise
# Attributes:: webstyles
#
# Copyright 2023-2025 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

default['arcgis']['webstyles'].tap do |webstyles|
  case node['platform']
  when 'windows'
    webstyles['setup'] = ::File.join(node['arcgis']['repository']['setups'],
                                     "ArcGIS #{node['arcgis']['version']}",
                                     'ArcGISWebStyles', 'Setup.exe').tr('/', '\\')

    case node['arcgis']['version']
    when '12.1'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_121_200163.exe').tr('/', '\\')
      webstyles['product_code'] = '{44120188-FA74-4E39-8691-68C7C4C9A25C}'
    when '12.0'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_120_197708.exe').tr('/', '\\')
      webstyles['product_code'] = '{A31A5861-3957-46E3-9166-56D297C0309E}'
    when '11.5'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_115_195369.exe').tr('/', '\\')
      webstyles['product_code'] = '{58668668-FCF9-400D-B3DF-24A3E0417C00}'
    when '11.4'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_114_192942.exe').tr('/', '\\')
      webstyles['product_code'] = '{2C941605-135F-4501-AD91-21ECA70977ED}'
    when '11.3'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_113_190232.exe').tr('/', '\\')
      webstyles['product_code'] = '{A477F9A0-A5E5-4BBF-8042-8503DE8AAEC5}'
    when '11.2'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_112_188251.exe').tr('/', '\\')
      webstyles['product_code'] = '{0508DE8B-B6B2-42AD-B955-77451C3ACB60}'
    when '11.1'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_111_185220.exe').tr('/', '\\')
      webstyles['product_code'] = '{67EDD399-CBD8-48C8-8B72-D79FBBBD79B2}'
    when '11.0'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_110_182886.exe').tr('/', '\\')
      webstyles['product_code'] = '{CCA0635D-E306-4C42-AB81-F4032D731397}'
    when '10.9.1'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Windows_1091_180053.exe').tr('/', '\\')
      webstyles['product_code'] = '{2E63599E-08C2-4401-8FD7-95AAA64EA087}'
    else
      Chef::Log.warn 'Unsupported ArcGIS Web Styles version'
    end
  else # node['platform'] == 'linux'
    webstyles['setup'] = ::File.join(node['arcgis']['repository']['setups'],
                                     node['arcgis']['version'],
                                     'WebStyles', 'WebStyles-Setup.sh')

    case node['arcgis']['version']
    when '12.1'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_121_200207.tar.gz')
    when '12.0'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_120_197822.tar.gz')
    when '11.5'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_115_195200.tar.gz')
    when '11.4'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_114_192979.tar.gz')
    when '11.3'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_113_190317.tar.gz')
    when '11.2'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_112_188339.tar.gz')
    when '11.1'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_111_185304.tar.gz')
    when '11.0'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_110_182985.tar.gz')
    when '10.9.1'
      webstyles['setup_archive'] = ::File.join(node['arcgis']['repository']['archives'],
                                               'Portal_for_ArcGIS_Web_Styles_Linux_1091_180201.tar.gz')
    else
      Chef::Log.warn 'Unsupported ArcGIS Web Styles version'
    end
  end

  webstyles['setup_options'] = ''
end
