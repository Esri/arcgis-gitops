#
# Cookbook Name:: arcgis-enterprise
# Recipe:: portal_standby
#
# Copyright 2023-2025 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

include_recipe 'arcgis-enterprise::install_portal'

# Set hostname in hostname.properties file.
template ::File.join(node['arcgis']['portal']['install_dir'],
                     node['arcgis']['portal']['install_subdir'],
                     'framework', 'etc', 'hostname.properties') do
  source 'hostname.properties.erb'
  owner node['arcgis']['run_as_user']
  group node['arcgis']['run_as_group']
  variables ( {:hostname => node['arcgis']['portal']['hostname']} )
  notifies :stop, 'arcgis_enterprise_portal[Stop Portal for ArcGIS]', :immediately
  not_if { node['arcgis']['portal']['hostname'].empty? }
end

# Set hostidentifier and preferredidentifier in hostidentifier.properties file.
arcgis_enterprise_portal 'Configure hostidentifier.properties' do
  action :configure_hostidentifiers_properties
end

arcgis_enterprise_portal 'Stop Portal for ArcGIS' do
  action :nothing
end

arcgis_enterprise_portal 'Start Portal for ArcGIS' do
  action :start
end

directory node['arcgis']['portal']['log_dir'] do
  owner node['arcgis']['run_as_user']
  mode '0700' if node['platform'] != 'windows'
  recursive true
  action :create
end

arcgis_enterprise_portal 'Join Portal Site' do
  portal_url node['arcgis']['portal']['url']
  primary_machine_url node['arcgis']['portal']['primary_machine_url']
  username node['arcgis']['portal']['admin_username']
  password node['arcgis']['portal']['admin_password']
  upgrade_backup node['arcgis']['portal']['upgrade_backup']
  upgrade_rollback node['arcgis']['portal']['upgrade_rollback']
  retries 5
  retry_delay 30
  action :join_site
end

arcgis_enterprise_portal 'Import Root Certificates' do
  portal_url node['arcgis']['portal']['url']
  username node['arcgis']['portal']['admin_username']
  password node['arcgis']['portal']['admin_password']
  root_cert node['arcgis']['portal']['root_cert']
  root_cert_alias node['arcgis']['portal']['root_cert_alias']
  not_if { node['arcgis']['portal']['root_cert'].empty? ||
           node['arcgis']['portal']['root_cert_alias'].empty?}
  retries 5
  retry_delay 30
  action :import_root_cert
end

arcgis_enterprise_portal 'Configure HTTPS' do
  portal_url node['arcgis']['portal']['url']
  username node['arcgis']['portal']['admin_username']
  password node['arcgis']['portal']['admin_password']
  keystore_file node['arcgis']['portal']['keystore_file']
  keystore_password node['arcgis']['portal']['keystore_password']
  cert_alias node['arcgis']['portal']['cert_alias']
  root_cert node['arcgis']['portal']['root_cert']
  root_cert_alias node['arcgis']['portal']['root_cert_alias']
  import_certificate_chain node['arcgis']['portal']['import_certificate_chain']
  hsts_enabled node['arcgis']['portal']['hsts_enabled']
  retries 5
  retry_delay 30
  action :configure_https
end
