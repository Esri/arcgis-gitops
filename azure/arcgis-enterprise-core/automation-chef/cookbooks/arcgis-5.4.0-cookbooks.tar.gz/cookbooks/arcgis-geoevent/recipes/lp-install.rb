#
# Cookbook Name:: arcgis-geoevent
# Recipe:: lp-isntall
#
# Copyright 2015 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

if node['platform'] == 'windows'
  windows_package 'Install GeoEventLP' do
    source node['arcgis']['geoevent']['lp-setup']
    action :install
    only_if Utils.product_installed?(node['arcgis']['geoevent']['product_code'])
  end
else
  package 'Install GeoeventLP' do
    source node['arcgis']['geoevent']['lp-setup']
    action :install
  end
end
