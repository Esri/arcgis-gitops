#
# Cookbook Name:: arcgis-enterprise
# Recipe:: system
#
# Copyright 2023-2025 Esri
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

chef_gem 'multipart-post' do
  ignore_failure true
  compile_time true
end

if platform?('windows')
  Utils.check_sensitive_value('arcgis.run_as_password', node['arcgis']['run_as_password'])

  user node['arcgis']['run_as_user'] do
    comment 'ArcGIS user account'
    manage_home true
    password node['arcgis']['run_as_password']
    not_if { node['arcgis']['run_as_user'].include? '\\' } # do not try to create domain accounts
    action :create
  end
else
  node['arcgis']['packages'].each do |package_install|
    package package_install do
      retries 5
      retry_delay 60
    end
  end 

  group node['arcgis']['run_as_user'] do
    gid node['arcgis']['run_as_gid']
    not_if "getent group #{node['arcgis']['run_as_user']}"
    action :create
  end

  user node['arcgis']['run_as_user'] do
    comment 'ArcGIS user account'
    manage_home true
    home '/home/' + node['arcgis']['run_as_user']
    shell '/bin/bash'
    uid node['arcgis']['run_as_uid']
    gid node['arcgis']['run_as_gid']
    not_if "getent passwd #{node['arcgis']['run_as_user']}"
    action :create
  end

  # limit 'example-1' do
  #   domain '*'
  #   type 'hard'
  #   item 'nofile'
  #   value 512
  # end

  ['hard', 'soft'].each do |t|
    limit "#{node['arcgis']['run_as_user']}-nofile-#{t}" do
      domain node['arcgis']['run_as_user']
      type t
      item 'nofile'
      value 65536
    end

    limit "#{node['arcgis']['run_as_user']}-nproc-#{t}" do
      domain node['arcgis']['run_as_user']
      type t
      item 'nproc'
      value 25059
    end

    limit "#{node['arcgis']['run_as_user']}-memlock-#{t}" do
      domain node['arcgis']['run_as_user']
      type t
      item 'memlock'
      value 'unlimited'
    end

    limit "#{node['arcgis']['run_as_user']}-fsize-#{t}" do
      domain node['arcgis']['run_as_user']
      type t
      item 'fsize'
      value 'unlimited'
    end

    limit "#{node['arcgis']['run_as_user']}-as-#{t}" do
      domain node['arcgis']['run_as_user']
      type t
      item 'as'
      value 'unlimited'
    end
  end

  # Rename ~/.ESRI.properties.<hostname>.<version> files to include
  # the correct hostname
  script 'Rename .ESRI.properties.*.* files' do
    interpreter 'bash'
    user node['arcgis']['run_as_user']
    cwd '/home/' + node['arcgis']['run_as_user']
    code <<-EOH
      for file in /home/arcgis/.ESRI.properties.* ; do
        oldhost=$(echo $file | cut -d'.' -f 4)
        newhost=$(hostname)
        newfile=$(echo $file | sed -e "s,$oldhost,$newhost,g")
        if [ ! -f $newfile ]; then
          mv $file $newfile
        fi
      done
    EOH
    only_if { ENV['arcgis_cloud_platform'] == 'aws' }
  end

  # Remove comment from #/net in /etc/auto.master
  file "/etc/auto.master" do
    content lazy { File.read("/etc/auto.master").gsub("#/net", "/net") }
    only_if { node['arcgis']['configure_autofs'] }
  end

  directory '/home/' + node['arcgis']['run_as_user'] + '/.ssh' do
    mode '0700'
    owner node['arcgis']['run_as_user']
    group node['arcgis']['run_as_user']
    not_if { node['arcgis']['run_as_user_auth_keys'].nil? }
    action :create
  end

  file '/home/' + node['arcgis']['run_as_user'] + '/.ssh/authorized_keys' do
    content lazy { File.read(node['arcgis']['run_as_user_auth_keys']) }
    mode '0600'
    owner node['arcgis']['run_as_user']
    group node['arcgis']['run_as_user']
    not_if { node['arcgis']['run_as_user_auth_keys'].nil? }
    action :create
  end

  service 'autofs' do
    only_if { node['arcgis']['configure_autofs'] }
    action [:enable, :reload, :restart]
  end
end

include_recipe 'arcgis-enterprise::hosts'
